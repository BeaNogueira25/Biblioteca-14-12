<?php
session_start();
require "conexao.php";
require "..\Modelo\livro.php";
require "..\Repositorio\livroRepositorio.php";

//if (isset($_POST['cadastro'])){ ou
if ($_SERVER["REQUEST_METHOD"]=="POST"){
    $nome = $_POST["nome"];
    $autor = $_POST["autor"];
    $descricao = $_POST["descricao"];
    $preco = $_POST["preco"];
    $imagem = $_FILES['imagem']['name'];
    
    $livro = new Livro( NULL,
        $nome,
        $autor,
        $preco,$descricao,$imagem
        );

    $LivroRepositorio = new LivroRepositorio($conn);
    if (isset($_FILES['imagem']) && ($_FILES['imagem']['error'] == 0)){
        $livro->setImagem(uniqid() . $_FILES['imagem']['name']);
        move_uploaded_file($_FILES['imagem']['tmp_name'], $livro->getImagemDiretorio());
    }
    $sucess = $LivroRepositorio->cadastrar($livro);
    if ($sucess){
        $codcad = rand(0, 1000000);
        echo "<form id='redirectForm' action='../admin.php' method='POST'>";
        echo "<input type='hidden' name='codigo' value={'$codcad'}>";
       
        echo "</form>";
        echo "<script>document.getElementById('redirectForm').submit();</script>";


       // header("Location: ../visao/admin.php?codcad=$codigo");
      //  exit();
    }else{
        echo "erro ao cadastrar produto";
    }
    
}