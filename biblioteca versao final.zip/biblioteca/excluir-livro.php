<!doctype html>
<?php

include 'controladora\conexao.php';
include 'Modelo\livro.php';
include 'Repositorio\LivroRepositorio.php';

$LivroRepositorio = new LivroRepositorio($conn);
$excluirLivro = $LivroRepositorio->excluirLivroPorId($_POST['id']);
 



?>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/form.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <title>IFSP - Editar livro</title>
</head>

<body>
    <main>
        <section class="container-admin-banner">
            <img src="assets/img/logo.png" class="logo-admin" alt="logo-biblioteca">
            <?php
            if ($excluirLivro) {

            ?>
                <h1>Livro excluído com sucesso</h1>
                <img class="ornaments" src="assets/img/banner1.png" alt="ornaments">
        </section>
        <section class="container-form">
            <form action="admin.php" method="post">
                <input type="submit" name="voltar" class="botao-cadastrar" value="voltar" />

            </form>
        <?php } else {
                echo "erro ao excluir Livro";
            } ?>

        </section>
    </main>
</body>

</html>