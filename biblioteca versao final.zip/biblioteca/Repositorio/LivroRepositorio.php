<?php
class LivroRepositorio
{
    private $conn; // Sua conexão com o banco de dados
    public function __construct($conn)
    {
        $this->conn = $conn;
    }
    public function cadastrar(Livro $produto)
    {
        $sql = "INSERT INTO livros ( nome,autor,preco, 
        descricao, imagem) VALUES (?,?,?,?,?)";
        $stmt = $this->conn->prepare($sql);
        $nome =  $produto->getNome(); 
        $autor =  $produto->getAutor();
        $preco =  $produto->getPreco();
        $descricao =   $produto->getDescricao();
        $imagem = "assets/img/gallery/". $produto->getImagem();
            
        $stmt->bind_param(
            "ssdss",
            $nome,
            $autor,
            $preco,
            $descricao,
            $imagem
            
        );

        // Executa a consulta preparada e verifica o sucesso
        $success = $stmt->execute();

        // Fecha a declaração
        $stmt->close();

        // Retorna um indicador de sucesso
        return $success;
    }


    public function listarPreco()
    {
        $sql = "SELECT * FROM livros
        ORDER BY preco";
        $result = $this->conn->query($sql);

        $livros = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $livro = new Livro(
                    $row['id'],
                    $row['nome'],
                    $row['autor'],
                    $row['descricao'],$row['preco'],
                    $row['imagem']
                    
                );
                $livros[] = $livro;
            }
        }

        return $livros;
    }
    public function atualizarLivro(Livro $livro)
    {
        $imagem = $livro->getImagem();
        if (empty($imagem)) {
            // Prepara a declaração SQL
            $sql = "UPDATE livros SET nome = ?, autor = ?,
            descricao = ?, preco = ? WHERE id = ?";
            $stmt = $this->conn->prepare($sql);

            // Extrai os atributos do objeto Produto
            $nome = $livro->getNome();
            $autor = $livro->getAutor();

            $descricao = $livro->getDescricao();

            $preco = $livro->getPreco();
            $id = $livro->getId();

            // Vincula os parâmetros
            $stmt->bind_param(
                'sssdi',
                
                $nome,
                $autor,
                $descricao,
                $preco,                
                $id
             
            );
            // Executa a declaração preparada
            $resultado = $stmt->execute();

            // Fecha a declaração
            $stmt->close();

            return $resultado;
        } else {
            // Prepara a declaração SQL
            $sql = "UPDATE livros SET nome = ?, autor = ?,
            descricao = ?, imagem = ?, preco = ? WHERE id = ?";

            $stmt = $this->conn->prepare($sql);
            // Extrai os atributos do objeto Produto
            $nome = $livro->getNome();
            $autor = $livro->getAutor();
            $descricao = $livro->getDescricao();
            $imagem = "assets/img/gallery/". $livro->getImagem();
            $preco = $livro->getPreco();
            $id = $livro->getId();

            // Vincula os parâmetros
            $stmt->bind_param(
                'ssssdi',
                $nome,
                $autor,
                $descricao,
                $imagem,
                $preco,
                $id
            );
            // Executa a declaração preparada
            $resultado = $stmt->execute();

            // Fecha a declaração
            $stmt->close();

            return $resultado;
        }
    }

    public function listarLivroPorId($id)
    {
        $sql = "SELECT * FROM livros 
          where id = ? ORDER BY preco LIMIT 1";

        // Prepara a declaração SQL
        $stmt = $this->conn->prepare($sql);

        // Vincula o parâmetro
        $stmt->bind_param('i', $id);

        // Executa a consulta preparada
        $stmt->execute();

        // Obtém os resultados
        $result = $stmt->get_result();

        $livro = null;

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            $livro = new Livro(
                $row['id'],
                $row['nome'],
                $row['autor'],$row['preco'],
                $row['descricao'],
                $row['imagem']
                
            );
        }

        // Fecha a declaração
        $stmt->close();

        return $livro;
    }
    

    public function excluirLivroPorId($id)
    {
        $sql = "DELETE FROM livros WHERE  
             id = ?";

        // Prepara a declaração SQL
        $stmt = $this->conn->prepare($sql);

        // Vincula o parâmetro
        $stmt->bind_param('i', $id);

        // Executa a consulta preparada
        $success = $stmt->execute();

        // Fecha a declaração
        $stmt->close();

        return $success;
    }


    public function listarLivros()
    {
        $sql = "SELECT * FROM livros 
        ORDER BY preco";
        $result = $this->conn->query($sql);

        $livros = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $livro = new Livro(
                    $row['id'],
                    $row['nome'],
                    $row['autor'],
                    $row['preco'],
                    $row['descricao'],
                  
                    $row['imagem']
                    
                );
                $livros[] = $livro;
            }
        }

        return $livros;
    }

    public function buscarTodos()
    {
        $sql = "SELECT * FROM livros ORDER BY  preco";
        $result = $this->conn->query($sql);

        $produtos = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $livro = new Livro(
                    $row['id'],
                    $row['nome'],
                    $row['autor'],
                    $row['descricao'],$row['preco'],
                    $row['imagem']
                    
                );
                $livros[] = $livro;
            }
        }

        return $livro;
    }
}
